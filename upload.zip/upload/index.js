'use strict';
const Alexa = require('alexa-sdk');

const APP_ID = "a48af926-f174-4353-8313-94889d03bb0c";

const HELP_MESSAGE = 'You can ask me how many times you have taken medicine today, or log medicine intake. What can I help you with?';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

const handlers = {
    'LaunchRequest': function () {
        this.response.speak("You have launched Remembrall.").listen(HELP_REPROMPT);
        this.emit(':responseReady');
    },
    'LogIntent': function () {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        const time = "";
        const confirmation = "Okay, I have logged your medicine intake at " + h + m + "PM.";
        this.response.speak(confirmation).listen(HELP_REPROMPT);
        this.emit(':responseReady');
        
        // var code = "var " + name + " = " + value + ";\n";
        // var data = new FormData();
        // data.append("code", code);
        // var url = "https://yonniluu.lib.id/api@dev/updateCode/"; // endpoint 
        // var xhr = new XMLHttpRequest();
        // xhr.open("POST", url, true);
        // xhr.onreadystatechange = function() {
        //     if (xhr.readyState == 4 && xhr.status == 200) {
        //         console.log(xhr.responseText);
        //     }
        // }
        // xhr.send(body);
    },
    // 'DeclareForLoop': function () {
    //     const beg = this.event.request.intent.slots.beg.value;
    //     const end = this.event.request.intent.slots.end.value;
    //     const confirmation = "You are creating a for loop that iterates from " + beg + " to " + end + ".";
    //     this.response.speak(confirmation).listen(HELP_REPROMPT);
    //     this.emit(':responseReady');

    //     var code = "for (i in range(" + beg + ", " + end + "):{\n}";
    //     var data = new FormData();
    //     data.append("code", code);
    //     var url = "https://yonniluu.lib.id/api@dev/updateCode/"; // endpoint
    //     var xhr = new XMLHttpRequest();
    //     xhr.open("POST", url, true);
    //     xhr.onreadystatechange = function() {
    //         if (xhr.readyState == 4 && xhr.status == 200) {
    //             console.log(xhr.responseText);
    //         }
    //     }
    //     xhr.send(code);
    // },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};